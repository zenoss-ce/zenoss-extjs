Ext.create('Ext.Button', {
    renderTo: document.body,
    text    : 'Click me',
    scale   : 'large'
});
