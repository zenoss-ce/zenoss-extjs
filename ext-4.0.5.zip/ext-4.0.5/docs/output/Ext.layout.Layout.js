Ext.data.JsonP.Ext_layout_Layout({
  "static": false,
  "mixedInto": [

  ],
  "inheritable": false,
  "xtypes": [

  ],
  "linenr": 1,
  "statics": {
    "css_var": [

    ],
    "cfg": [

    ],
    "css_mixin": [

    ],
    "event": [

    ],
    "method": [

    ],
    "property": [

    ]
  },
  "extends": "Object",
  "html_filename": "Layout.html",
  "allMixins": [

  ],
  "docauthor": null,
  "href": "Layout.html#Ext-layout-Layout",
  "subclasses": [
    "Ext.layout.container.AbstractContainer"
  ],
  "protected": false,
  "members": {
    "css_var": [

    ],
    "cfg": [

    ],
    "css_mixin": [

    ],
    "event": [

    ],
    "method": [

    ],
    "property": [

    ]
  },
  "deprecated": null,
  "singleton": false,
  "private": false,
  "tagname": "class",
  "author": null,
  "superclasses": [

  ],
  "alias": null,
  "name": "Ext.layout.Layout",
  "mixins": [

  ],
  "code_type": "ext_define",
  "component": false,
  "filename": "/Users/nickpoulden/Projects/sencha/SDK/platform/src/layout/Layout.js",
  "doc": "<p>Base Layout class - extended by ComponentLayout and ContainerLayout</p>\n",
  "alternateClassNames": [

  ]
});